namespace PetClinic.PaymentService;

public record Pet(int id, string name, DateTime birthDate);