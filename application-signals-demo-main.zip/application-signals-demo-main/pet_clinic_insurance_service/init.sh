python manage.py migrate
python manage.py loaddata initial_data.json --database=default