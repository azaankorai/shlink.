from django.contrib import admin

# Register your models here.
from .models import Insurance

admin.site.register(Insurance)