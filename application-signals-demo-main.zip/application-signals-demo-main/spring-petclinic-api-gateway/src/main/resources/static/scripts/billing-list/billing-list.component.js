"use strict";

angular.module("billingList").component("billingList", {
    templateUrl: "scripts/billing-list/billing-list.template.html",
    controller: "BillingListController",
});
