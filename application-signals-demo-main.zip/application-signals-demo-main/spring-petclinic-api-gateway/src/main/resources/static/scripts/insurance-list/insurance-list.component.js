"use strict";

angular.module("insuranceList").component("insuranceList", {
    templateUrl: "scripts/insurance-list/insurance-list.template.html",
    controller: "InsuranceListController",
});
