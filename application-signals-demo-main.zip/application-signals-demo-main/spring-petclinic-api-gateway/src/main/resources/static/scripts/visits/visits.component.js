'use strict';

angular.module('visits')
    .component('visits', {
        templateUrl: 'scripts/visits/visits.template.html',
        controller: 'VisitsController'
    });
