"use strict";

angular.module("paymentForm").component("paymentForm", {
  templateUrl: "scripts/payment-form/payment-form.template.html",
  controller: "paymentFormController",
});
