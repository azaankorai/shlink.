package org.springframework.samples.petclinic.api.dto;

import lombok.Data;

@Data
public class
PetNutrition {
    private String pet_type;

    private String facts;
}
